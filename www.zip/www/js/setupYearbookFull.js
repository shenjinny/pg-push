
   		   

function createYearbookEntry() {

								db.transaction(
								function(transaction) {


transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1963,"Campbell","Jonathan","Associate Client Partner","Client Partner Group","WINNERS","YES","YES","","","10","2013-04-20 15:44:00","yearbook/updates/1963.jpg");');
transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1996,"Cox-Swafford","Jolynn","Sr Account Executive","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-18 23:58:00","yearbook/updates/1996.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2452,"Way","Krista","Account Manager","Event Sales ","WINNERS","NO","YES","","","10","2013-04-18 23:45:00","yearbook/updates/2452.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2439,"Valladao","Vinicius","Account Executive","Americas Major Accounts","WINNERS","YES","YES","","","10","2013-04-18 23:43:00","yearbook/updates/2439.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2426,"Tholt","Carlos","Area Manager","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-18 23:41:00","yearbook/updates/2426.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2480,"Zapparoli","Alexandre Thiele","Account Executive","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-18 23:39:00","yearbook/updates/2480.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2421,"Taylor","Gary","Business Development Mgr ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-18 23:31:00","yearbook/updates/2421.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2314,"Possidento","Joseph","Sr Account Manager ","Event Sales ","WINNERS","NO","YES","","","10","2013-04-18 23:26:00","yearbook/updates/2314.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2173,"Klobnock","Andrew","Sr Account Executive","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-18 23:21:00","yearbook/updates/2173.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2170,"Kirmaci","Hassen","Area Manager","Europe Sales ","WINNERS","NO","YES","","","10","2013-04-18 23:15:00","yearbook/updates/2170.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2132,"Holden","Christian","Business Development Mgr","North America SMB ","WINNERS","NO","YES","","","10","2013-04-18 23:12:00","yearbook/updates/2132.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2116,"Hardy","Stephen","Sr Account Executive SMB","Europe Sales ","WINNERS","NO","YES","","","10","2013-04-18 23:08:00","yearbook/updates/2116.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2066,"Forcino","John","Account Manager ","Event Sales ","WINNERS","NO","YES","","","10","2013-04-18 21:48:00","yearbook/updates/2066.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2448,"Waechter","Chris","Sr Account Manager","Event Sales ","WINNERS","NO","YES","","","10","2013-04-18 21:34:00","yearbook/updates/2448.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2201,"Lorson","Seth","Event Attendance Specialist","Event Sales ","WINNERS","NO","NO","","","10","2013-04-18 18:42:00","yearbook/updates/2201.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1972,"Cheriyan","Thomas","Account Manager ","Event Sales ","WINNERS","NO","YES","","","10","2013-04-18 17:12:00","yearbook/updates/1972.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2054,"Faramo","Rachel","Area Manager","Americas Major Accounts","WINNERS","YES","YES","","","10","2013-04-17 17:11:00","yearbook/updates/2054.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1959,"Butt","Nasar","Account Manager ","Event Sales ","WINNERS","NO","YES","","","10","2013-04-17 17:00:00","yearbook/updates/1959.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1926,"Ayoub","Tania","Client Director","Americas Strategic Accounts Organization ","WINNERS","YES","NO","","","10","2013-04-17 16:34:00","yearbook/updates/1926.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2538,"Schwartz","Lew","SVP, General Counsel","","OC","NO","NO","","","410","2013-04-17 09:13:00","yearbook/updates/2538.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2449,"Walden","Blake","Business Development Mgr ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-16 18:29:00","yearbook/updates/2449.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2055,"Farnhill","James","Sales Associate","Europe Sales ","WINNERS","NO","YES","","","10","2013-04-16 17:42:00","yearbook/updates/2055.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2324,"Raphaelian","David","Sr Account Manager ","Event Sales ","WINNERS","YES","YES","","","10","2013-04-16 17:39:00","yearbook/updates/2324.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2459,"Whitaker","Keith","Area Manager ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-16 17:05:00","yearbook/updates/2459.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2351,"Ross","Jack","Account Manager","Event Sales ","WINNERS","NO","YES","","","10","2013-04-16 16:41:00","yearbook/updates/2351.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2226,"Maupin","Lisah","Business Development Mgr","North America SMB ","WINNERS","NO","YES","","","10","2013-04-16 15:44:00","yearbook/updates/2226.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2389,"Slattery","Mike","Business Development Mgr ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-16 15:40:00","yearbook/updates/2389.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2313,"Poplawski-Kreie","Donna","Sales Specialist","Competitive Specialist ","WINNERS","YES","YES","","","10","2013-04-16 15:30:00","yearbook/updates/2313.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2008,"Daharsh","Michael Martin","Business Development Mgr ","North America SMB ","WINNERS","YES","YES","","","10","2013-04-16 15:13:00","yearbook/updates/2008.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2040,"Dyson","Amanda","Client Partner Manager","Client Partner Group","WINNERS","NO","YES","","","10","2013-04-16 14:48:00","yearbook/updates/2040.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1991,"Correia","Steve","Business Development Mgr ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-16 14:41:00","yearbook/updates/1991.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1945,"Boggs","Carla Blalock","Account Executive","Americas Major Accounts ","WINNERS","NO","NO","","","10","2013-04-15 16:40:00","yearbook/updates/1945.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1912,"Agarwal-Pandey","Pooja","Sr Account Executive","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-11 11:30:00","yearbook/updates/1912.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1917,"Ali","Roxy","Account Manager ","Event Sales ","WINNERS","YES","YES","","","10","2013-04-11 11:30:00","yearbook/updates/1917.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1920,"Arroyo-Arias","Carlos","Sales Agent ","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-11 11:30:00","yearbook/updates/1920.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2496,"Thomas","Chris","GVP","","OC","NO","NO","Americas Major Accounts","","385","2013-04-11 11:30:00","yearbook/updates/2496.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2532,"Godfrey","David","SVP, Worldwide Sales","","OC","NO","NO","","","450","2013-04-11 11:30:00","yearbook/updates/2532.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2013,"D\'Argentre","Alexis","Client Director","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-11 11:07:00","yearbook/updates/2013.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2012,"D\'Amico ","Stacy","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-11 11:06:00","yearbook/updates/2012.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2213,"Mansell-Cook","Ally","Event Attendance Specialist","Event Sales ","WINNERS","NO","NO","","","10","2013-04-11 11:05:00","yearbook/updates/2213.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2233,"McHenry-Annesley","Ronda","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-11 11:05:00","yearbook/updates/2233.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2257,"Moreau-Dionnet ","Sonia","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-11 11:05:00","yearbook/updates/2257.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2290,"Park-Weir","Becky","Client Partner Manager","Client Partner Group","HOST","NO","NO","Client Partner Group","","10","2013-04-11 11:05:00","yearbook/updates/2290.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2345,"Robison-Rivera","Fiona","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-11 11:05:00","yearbook/updates/2345.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2364,"Sant\'Anna ","Mauricio","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-11 11:05:00","yearbook/updates/2364.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2283,"Padwa","Jill","Client Director","Americas Strategic Accounts Organization","REMOVE","NO","NO","","","10","2013-04-11 10:30:00","yearbook/updates/2283.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2042,"Ehsan","Asif","Account Manager ","Event Sales ","WINNERS","NO","YES","","","10","2013-04-11 10:20:00","yearbook/updates/2042.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2131,"Hogben","Peter","Account Manager ","Event Sales ","WINNERS","NO","YES","","","10","2013-04-11 10:20:00","yearbook/updates/2131.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1997,"Craven-Wilkinson","Edward","Account Manager ","Event Sales ","WINNERS","NO","YES","","","10","2013-04-11 10:10:00","yearbook/updates/1997.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1998,"Creane","Jason","Account Manager SMB","Europe Sales ","WINNERS","NO","YES","","","10","2013-04-11 10:10:00","yearbook/updates/1998.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2256,"Morales","Diana","Account Executive SMB","Europe Sales ","WINNERS","YES","YES","","","10","2013-04-11 10:00:00","yearbook/updates/2256.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2269,"Nakanoo","Yumi","Client Partner","Japan Sales","WINNERS","NO","NO","","","10","2013-04-10 12:00:00","yearbook/updates/2269.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (3001,"Zurita","Alfonso","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-10 09:00:00","yearbook/updates/3001.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2511,"Hunter","David","GVP","","HOST","NO","NO","Emerging Markets - India & CEEMEA","","10","2013-04-06 15:49:00","yearbook/updates/2511.jpg");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1909,"Abbott","Julie","Area Manager ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1910,"Abbou","Sophian","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1911,"Achirica","Jorge","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1913,"Ajroldi","Giuseppe","Account Executive SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1914,"Akimoto","Takashi","Sr Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1915,"Akinsanya","Michael","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1916,"Albert","Stephanie","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1918,"Apostolakos","Steven","Sr Account Executive ","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1919,"Aravich","Dayna","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1921,"Arvidsson","Lena","Account Executive SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1922,"Asai","Junji","Area Manager","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1923,"Aspesi","Maria Cristina","Client Director","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1924,"Astley","Melody","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1925,"Avolio","Anne Michelle","Client Director","Americas Strategic Accounts Organization ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1927,"Azodi","Nima","Client Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1928,"Badamo","Brandon","Client Partner","Client Partner Group ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1929,"Bain","Nicola","Client CIO Specialist","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1930,"Bains","Suki","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1931,"Baird","Roxanne","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1932,"Barker","Kimberly","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1933,"Belcastro","Christy","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1934,"Beougher","Tony","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1935,"Bertram","Jim","Client Director","Americas Strategic Accounts Organization ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1936,"Bhalla","Saurabh","Area Manager","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1937,"Bianco","Mark","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1938,"Birch","Steve","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1939,"Bitar","Pascal","Account Executive","Americas Major Accounts ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1940,"Blackwell","Winston C.","Sr Account Executive","Americas Major Accounts ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1941,"Blekken","Dordi","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1942,"Bloor","Hugh","Account Executive SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1943,"Blumenthal","Richard","Area Manager ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1944,"Boe","Petter","Sr Account Executive ","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1946,"Boivineau","Arnaud","Associate Client Partner","Client Partner Group ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1947,"Bonacci","Steve","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1948,"Booth","Stephanie","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1949,"Bourke","Cory","Business Development Mgr","North America SMB ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1950,"Bradley","Denise","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1951,"Brady","John","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1952,"Bras","Norbert","Client Partner","Client Partner Group ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1953,"Brauer","Jennifer","Account Manager SMB","NA SMB","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1954,"Bridwell","Jerianne","Client CIO Specialist","Competitive Specialist ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1955,"Broad","Philip","Client Partner","Client Partner Group ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1956,"Broadway","Matt","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1957,"Bryant","Iain","Account Executive","Americas Strategic Accounts ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1958,"Bryce","Mandy","Sales Agent - Sales","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1960,"Button","Amy","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1961,"Callegari","Josephine","Area Manager","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1962,"Camilleri","Anne-Laure","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1964,"Campero","Hernan","Business Development Executive","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1965,"Campi","Perry Vincent","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1966,"Cannon","Jen","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1967,"Cantu","Cristiano","Area Manager","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1968,"Cappello","Robert","Account Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1969,"Carisi","Roberto","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1970,"Cereceda","Inigo","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1971,"Chavda","Kal","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1973,"Chiappe","John","Business Development Director","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1974,"Chilampath","Samson","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1975,"Choate","Allen","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1976,"Choinski","Mischelle","Regional VP Sales","Americas Major Accounts","WINNERS","YES","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1977,"Christensen","Eric","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1978,"Christopher","Joe","Event Attendance Specialist","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1979,"Cipollaro","Kevin","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1980,"Clark","Jennifer","Sr Account Executive","Americas Strategic Accounts Organization ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1981,"Clarke","Megan","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1982,"Clarke","Mike","Sr Account Executive SC","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1983,"Cleary","Conor","Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1984,"Coleman ","Dominic","VP & Client Director","Americas Strategic Accounts Organization ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1985,"Collins ","Craig","Client Director","Americas Strategic Accounts Organization ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1986,"Comunale ","Christine","Client Partner Manager","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1987,"Conley","Jay","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1988,"Copley","Ashley","Business Development Mgr","North America SMB ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1989,"Cordero","Pia Chong","Account Executive SMB","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1990,"Corr","Jimmy","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1992,"Costa Paiva","Rodrigo","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1993,"Courson","Stephen","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1994,"Cox","Nigel","Director","Event Sales ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1995,"Cox","Ryan G. ","Sr Account Executive","Americas Strategic Accounts Organization ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (1999,"Cronin","Robert","Sales Specialist ","Competitive Specialist ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2000,"Crow","Lisa","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2001,"Crowel","Dawn","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2002,"Cruz","Joe","Client Executive","Americas Strategic Accounts Organization ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2003,"Cui","James","Area Manager","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2004,"Cunliffe","Hugh","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2005,"Cunningham","Jack","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2006,"Cunningham","Tom","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2007,"Cyrus","Rod","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2009,"Dal Santo","Joe","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2010,"Daley","Marcia","Account Executive","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2011,"Damenti","Michael A.","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2014,"Daruwala","Nik","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2015,"Dau","Daniel","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2016,"David","Dominic","Sr Account Executive SMB","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2017,"Davidson","Rhiannon","Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2018,"Davin","Morgan","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2019,"De La Torre","Rogelio","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2020,"De Nicolo","Gianfranco","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2021,"Dea","Donna","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2022,"Del Pizzo","Mike","Account Executive ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2023,"DeMonte ","Chad","Business Development Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2024,"Dermody","Paul","Sr Account Executive","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2025,"Derne","Stephane","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2026,"Deshpande","Devika","Account Executive SMB","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2027,"Dhawan","Rishi","Area Manager","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2028,"Didieo","Misty","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2029,"Dillingham","Kate","Account Manager ","North America SMB ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2030,"Dolan","Gina","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2031,"Dolansky ","Mark","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2032,"Dommes","Jon","Business Development Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2033,"Donnelly","Dan","Sr Account Executive, Invest","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2034,"Dorzhiev","Sayan","Sales Agent","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2035,"Dougan","Fiona","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2036,"Dubien","Antoine","Client Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2037,"Duebelbeis","Kenny","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2038,"Dunn","Nicole","Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2039,"Dunne","Mark","Sr Account Manager ","Event Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2041,"Egan","Stefanie","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2043,"Eide","Carri","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2044,"Elgstedt","Myxa","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2045,"Ellis","Nancy","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2046,"Ellsworth ","Brad","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2047,"Embil","Jesus","Client Director","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2048,"Erlach","Monika","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2049,"Erler","Julie K.","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2050,"Eron","Heather","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2051,"Ervans","Jeannine","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2052,"Falkingham","Alex","Business Development Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2053,"Farahmand","Philip","Sr Account Executive ","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2056,"Fattoruso","Alexander","Client Director","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2057,"Fay Jr.","Jim","Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2058,"Feinstein","David","Business Development Mgr ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2059,"Ferraro","Ben P.","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2060,"Finbow","Richard","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2061,"Fischer","Patrick","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2062,"Fitzer","Tera","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2063,"Fitzgerald","Caileen","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2064,"Flaig","Julie","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2065,"Fogarty","Liz","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2067,"Forsling","Marcus","Client Director","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2068,"Fowler","Adrian","Area Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2069,"Franch","Kim","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2070,"Free","Larry","Regional VP Sales","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2071,"Friedman","Howard","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2072,"Fukumoto","Koichi","Area Manager","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2073,"Funge","James","Area Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2074,"Furum","Palle","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2075,"Gadre","Ramesh","Account Executive SMB","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2076,"Galenkamp","Chris","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2077,"Galli","Massimiliano","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2078,"Gannon","Bill","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2079,"Garofolo","Dana","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2080,"Garrett","Adam","Account Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2081,"Garry","Angela","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2082,"Gascoigne","Bradley J","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2083,"Gassa","Dounia","Area Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2084,"Geerts","Anita","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2085,"Gentile","Victor","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2086,"Genys","Tatjana","Client Partner Manager","Client Partner Group","HOST","NO","NO","Client Partner Group","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2087,"Gerbi","Roberto","Sr Account Executive","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2088,"Ghilardi","Dario","Client Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2089,"Giard","Ashlea Marie","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2090,"Gibertoni","Stephen","VP, Named Accounts","Event Sales ","WINNERS","YES","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2091,"Giordano","Liz","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2092,"Goel","Ankur","Area Manager","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2093,"Goodman","Lauren","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2094,"Goodwin","Dave","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2095,"Graziani","Stephen","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2096,"Gregorich","Marc","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2097,"Griffin","Simeon","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2098,"Groth","T.J.","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2099,"Gruet","Julien","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2100,"Guellert","Tom","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2101,"Guidi","Joe","Business Development Mgr ","North America SMB ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2102,"Gunderson","Rob","Global Account Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2103,"Gutierrez","Ana","Client Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2105,"Haber","Tracey J.","Regional VP Sales","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2106,"Haberland","Angela","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2107,"Haga","Hans Johan","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2108,"Hall ","Richard","Sr Account Executive","Competitive Specialist ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2109,"Hamilton","Marisa","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2110,"Hammett","Shawn","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2111,"Hammock","Erin Paige","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2112,"Handman","Daniel","Manager Custom Newsprints","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2113,"Hanson","Matthew","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2114,"Harbinson","Heather J.","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2115,"Harcup","Jeremy","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2117,"Harris","Paulette","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2118,"Harris","Jane","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2119,"Hartung","Christiane","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2120,"Hartzell","Andrew","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2121,"Hartzell","Benjamin","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2122,"Harvey","David","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2123,"Hashimoto","Sachio","Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2124,"Heath","Bradley","Event Attendance Specialist","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2125,"Hemson","Alan","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2126,"Henry","Greg","Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2127,"Hernandez","Mary Kate","Supply Chain Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2128,"Hill","Darren","Area VP","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2129,"Hoffert","William","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2130,"Hogan","Paul","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2133,"Hongladarom","Varavich","Agent Employee Principal","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2134,"Hughes","Michelle","Client Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2135,"Hugon","Gabriel","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2136,"Hunter ","Edward","Manager, EAS ","Event Sales ","WINNERS","YES","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2137,"Hussain","Omar","Account Executive SMB","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2138,"Ingersoll ","Ben","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2139,"Irwin","Andrea","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2140,"Isemura","Satoshi","Account Executive","Japan Sales","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2141,"Itoh","Tomohiko","Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2142,"Iwai","Ryoko","Sr Account Manager Events","Japan Sales","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2143,"Jan","Adnan","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2144,"Javurkova","Petra","Sales Agent Sales","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2146,"Jenkins","Kathy","Sr Account Executive","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2147,"Jin ","Lena","Account Executive","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2148,"Johansen","Thomas","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2149,"Johnson","DeAnne","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2150,"Johnson","Joyce","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2151,"Johnson","Mike","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2152,"Johnston","Todd","Regional VP ","North America SMB ","WINNERS","YES","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2153,"Jonson","Randy","Sr Account Executive, Invest","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2154,"Joshi","Pinakin","Account Executive SMB","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2155,"Joshi","Rohit","Sr Account Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2156,"Judge","Martin","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2157,"Junck","Andreas","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2158,"Junior","Mauricio","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2159,"Kaisin ","Valerie","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2160,"Kardokas","Karolis","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2161,"Kelliher","Jerry","Account Executive SMB","ANZ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2162,"Kelly","Teri Ann","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2163,"Kendall","Debbie","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2164,"Kennison","David","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2165,"Kenny","David","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2166,"Khan","Imtiaz Ali","Area Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2167,"King","Amanda","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2168,"King","Simon","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2171,"Kiser","Michael","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2172,"Klaeren","Oliver","Client Director","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2174,"Knisely","Bryan","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2175,"Koehler","Monique","Account Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2176,"Koibuchi","Tatsuya","Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2177,"Kolodynski","Anthony","Account Executive","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2178,"Kortum","Kimberly","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2179,"Kosh","Paige","Area Manager SMB","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2180,"Kouritzin","Angela","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2181,"Krol","Ewa","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2182,"Kudrnova","Marketa","Sales Agent - Sales","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2183,"Kumar","Arun","Account Executive SMB","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2184,"Lamb","Jim","Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2185,"Lambert","Stephanie","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2186,"Last ","Matthew","Area Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2187,"Le Vavasseur","Olivier","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2188,"LeBlanc","Lucas","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2189,"Lee","Maggie","Account Executive","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2190,"Lenti","Laura","Area Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2191,"Lepore","Linda ","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2192,"Leslie ","Chris","RVP","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2193,"Levi","Glenn","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2194,"Levy","Pierre","Area VP","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2195,"Li","David","Area Manager","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2196,"Lieberman","Mark","Account Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2197,"Lilly","Leigh Ann","Account Manager","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2198,"Lim","Jack","Sr Account Executive","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2199,"Lindstrup","Marcus","Regional VP SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2200,"Lison","Joe","Business Development Mgr ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2202,"Losada","Frank","Account Manager","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2203,"Lubs","Chris","Sr Account Executive SC","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2204,"Luetchford","Paul","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2205,"Luhrsen","Dane K.","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2206,"Lyrio","Celso Chapinotte","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2207,"Magnusson","Kristen","Sr Account Executive SMB","North America SMB ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2208,"Mahabir","Francis","Business Development Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2209,"Maher","Michael","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2210,"Maistry","Kiran","Account Executive","Europe Sales ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2211,"Manchanda","Rohit","Account Executive","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2212,"Mandrekar","Kartik","Account Executive ","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2214,"Marcon","Riccardo","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2215,"Martin","Jo","Sr Account Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2216,"Martin","Laurence","Client Director","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2217,"Martin","Ryan","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2218,"Martinez","James","Business Development Mgr","North America SMB ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2219,"Mascherona","Mauro","Sales Specialist","Europe Sales ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2220,"Mason","Ronald","Account Manager","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2221,"Matias","Ricardo","Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2222,"Matos","Cheyenne","Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2223,"Matsumoto","Koji","Sr Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2224,"Matsumoto","Yuki","Account Executive","Japan Sales","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2225,"Mattson","Clint","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2227,"Mazza","Ray","Area Manager","Competitive Specialist ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2228,"McCarthy","Lucy","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2229,"McDaniel","Tyler","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2230,"McDole","Shannon","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2231,"McDowall","Jane","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2232,"McGrath","Michael P.","VP","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2234,"McInerny","John","Area Manager","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2235,"McInnis","Joshua","Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2236,"McIntyre","Jan","Global Account Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2237,"McKitrick","Kent","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2238,"McLaren","John","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2239,"Meacham","Jamie","Business Development Mgr ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2240,"Meaders","Joel","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2241,"Medlock","Kathryn","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2242,"Mehra","Gautam ","Event Attendance Specialist","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2243,"Migliorini","Luca","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2244,"Migliorini Jr.","Lou","Area Manager","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2245,"Miguelez","Juan Pablo","Account Executive","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2246,"Mikuta","Kevin","Sr Account Executive SC","Supply Chain ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2247,"Miller","Stephen","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2248,"Millstone","Claudia","Sr Account Manager","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2249,"Minett","Chelsee","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2250,"Mitselmakher ","Kate","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2251,"Miyawaki","Yushi","Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2252,"Moe","Holly A","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2253,"Moeller","Amy ","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2254,"Moklebust","Tiffany A.","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2255,"Montgomery","Doug","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2258,"Moreira","Ricardo","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2259,"Morris","Devin","Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2260,"Morrison","Paul","Regional VP SMB","Europe Sales ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2262,"Motey","Laurie","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2263,"Motie","Amin","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2264,"Mueller","Stephanie T.","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2265,"Mukai","Shunsuke","Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2266,"Mulett","Martha "," Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2267,"Muramatsu","Kazuhiko","Account Executive","Japan Sales","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2268,"Murnin","Meghan","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2270,"Natta","Jean-Marc","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2271,"Neckar","John","Account Manager","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2272,"Nehme","Elie","Account Executive","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2273,"Nemeskal","Kimberly","Area Manager","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2274,"Netto","Gustavo Barbosa","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2275,"Nijjar","Ikroop","Account Executive SMB","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2276,"Noon","Jerome","Client Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2277,"Ohtani","Mauricio","Area Manager","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2278,"Okla","Steve","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2279,"Olsen","Jennifer L.","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2280,"Organ","Kathryn","Area Manager ","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2281,"Orozco","Salvador","Area Manager","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2282,"Ozaki","Takashi","Account Executive","Japan Sales","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2284,"Paesen","Jeroen","Client Partner Manager","Client Partner Group","HOST","NO","NO","Client Partner Group","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2285,"Page","Matthieu","Client Partner","Client Partner Group","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2286,"Pagey","Rohan","Account Manager","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2287,"Pape","Nick","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2288,"Parker","Matt","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2289,"Parkinson","Allana","Sr Account Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2291,"Parry","Chris","Event Attendance Specialist","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2292,"Partridge","Jonathan","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2293,"Pastrello","Jose","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2294,"Patterson","Michael","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2295,"Payne","Darren","Area Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2296,"Pearson","Phil Pearson","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2297,"Peixoto","Andre Cortines","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2298,"Perez","Annie","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2299,"Perez","Arantxa","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2300,"Perrone","Gianluca","Client Director","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2301,"Perry","Tad","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2302,"Persson","Erik","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2303,"Phan","Lily","Sr Account Executive SMB","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2304,"Pick","Geert","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2305,"Picken","Arthur","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2306,"Pierce","Matthew","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2307,"Pierson","Scott","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2308,"Piketty","Stephanie","Client Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2309,"Pittman","Corey","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2310,"Plavnik","Kent","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2311,"Polcyn","Agata","Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2312,"Polk","Patrick","Director","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2315,"Price","Geraldine","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2316,"Price","Kevin John","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2317,"Psalmon","Mathieu","Client Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2318,"Queen","Mark","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2319,"Rajnikant","Namita","Sr Account Executive","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2320,"Ramer","Eileen L.","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2321,"Ramos","Christina","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2322,"Ramsay","Alex","Sr Account Executive","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2323,"Rao","Arun H.","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2325,"Rasi","Paolo","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2326,"Rastetter","Ryan","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2327,"Rausch Allen","Alexis","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2328,"Raynor","Kiersten","Business Development Executive","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2329,"Redij","Sameer","Area Manager SMB","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2330,"Reed","Raymond L.","Client Director","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2331,"Reesing","Jeffrey","Regional VP Sales","Americas Major Accounts","WINNERS","YES","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2332,"Reeves","Stefani","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2333,"Reilly","Mike","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2334,"Reiss","Steven","Account Manager","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2335,"Renmans","Bram","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2336,"Reynolds","Eli","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2337,"Ricaurte","Chris","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2338,"Rich","Michelle","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2339,"Richards","Andrew","Director","Event Sales ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2340,"Rinello","John","RVP, Sales Operations","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2341,"Roberti","Celso","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2342,"Roberts","Jennifer","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2343,"Robinson","Bliss Simmons","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2344,"Robinson","Greg","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2346,"Roboz","Adrienne Jay-Jay","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2347,"Rogers","John L.","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2348,"Romanchuk","Rod","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2349,"Ronco","Alison N.","Client Partner Manager","Client Partner Group","WINNERS","YES","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2350,"Rose","Scott","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2352,"Rotigel","Daniel","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2353,"Rubenak","Thomas","Sr Account Executive, Invest","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2354,"Runow","Julia","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2355,"Rushton","Andy","Sr Account Manager","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2356,"Russell","DeLaine","Client Director","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2357,"Russo","Chris","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2358,"Saely","Claude","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2359,"Saini","Gaurav","Area Manager SMB","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2360,"Sakata","Akio","Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2361,"Salen","Caroline","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2362,"Sanchez","Susana","Sr Account Executive ","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2363,"Sanchez","Susana","Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2365,"Santos","Claudio","Sr Account Executive","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2366,"Sarfo","Margaret","Account Executive SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2367,"Satyarthe","Priya","Account Executive SMB","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2368,"Schmidt","Jonathan","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2369,"Schmidt","Victoria","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2370,"Schwartz","Chelsea","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2371,"Schweiger","Craig","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2372,"Seabring Watts","Virginia","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2373,"Segal","Justin","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2374,"Senecal","Emma","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2375,"Shamanna","Lokesh","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2376,"Shapira","Nancy","Account Executive","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2377,"Sheard","Kere","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2378,"Sherbrook","Christine","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2379,"Sherter","Craig","Sr Account Manager Events","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2380,"Sikarwar","Laghu","Account Executive SMB","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2381,"Silacci","Nicole","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2382,"Silver","Lauren","Supply Chain Client Partner","Client Partner Group","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2383,"Simonetti ","Kristen","Area Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2384,"Singh","Anup","Sr Account Executive","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2385,"Singh","Namrata","Account Executive","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2386,"Sipples","Christine","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2387,"Sjaavik","Espen Dusik","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2388,"Skagen","Gisle","Area VP","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2390,"Smedberg","Brad","Regional VP SMB","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2391,"Smerchansky","Derrick","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2392,"Smith","Franziska","Client Partner Manager","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2393,"Smith","Miranda M.","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2394,"Snelwar ","Daniel","VP & Client Director","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2395,"Sorkin","David","Director","Event Sales ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2396,"Sorley","Ryan","Area VP","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2397,"Spakouskas","Andrew","Area Manager","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2398,"Spalding","Mellie","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2399,"Spanner","Anna","Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2400,"Sprecher","Bradley","Regional VP Sales","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2401,"Staffen","Marcus","VP","Event Sales ","WINNERS","YES","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2402,"Stambouli","Kamel","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2403,"Stedman","Peter Mark","Account Manager SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2404,"Stellati","Alessio","Account Executive","Europe Sales ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2405,"Stephens","Kim R.","AVP, CPG","Client Partner Group","WINNERS","YES","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2406,"Stirling","Jim","Area Manager","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2407,"Stockham","Lak","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2408,"Stodghill","Matt","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2409,"Stroka","Chris","Business Development Mgr ","North America SMB ","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2410,"Strombeck","Dawn","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2411,"Strout","Audrey","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2412,"Su","Sam","Account Executive","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2413,"Sun","Leon","Sr Account Executive","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2414,"Suzuki","Shinsuke","Account Executive","Japan Sales","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2415,"Syrad","Rob","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2416,"Tambling","Andrew","Supply Chain Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2417,"Tamulionis","Stephanie","Sr Client Partner","Client Partner Group","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2418,"Tan","Elektra","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2419,"Tanaka","Hiroki","Account Executive","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2420,"Tate","Evan","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2422,"Tenwolde","Julie","VP & Client Director","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2423,"Theelen ","Nelleke","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2424,"Thewissen","Philippe","Client Director","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2425,"Thibodeau","Joe","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2427,"Thomas","Dwight","Account Executive SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2428,"Timbers","Betsy","Supply Chain Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2429,"Tomov","Francoise","Client Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2430,"Tooze","Chris","Director","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2431,"Topliss","Ian","Regional VP Sales","Emerging Markets - India & CEEMEA","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2432,"Trevino","Bernardo","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2434,"Tristao","Deborah","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2435,"Tsuchiya","Hironobu","Area Manager","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2436,"Uemura","Hironori","Account Executive","Japan Sales","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2437,"Ulrich","Emily","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2438,"Vaillant","Stephan","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2440,"Valverde","Ernane","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2441,"Van Den Broeke","Peter","Client Director","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2442,"Van Dongen","Corne","Area Manager","Americas Major Accounts","WINNERS","NO","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2443,"Velloso","Cesar","Area VP","Americas Major Accounts","WINNERS","YES","YES","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2444,"Verma","Yogesh","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2445,"Vestey","Roger","Area VP","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2446,"Vranckx","Peter","Account Executive","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2447,"Waclawiczek","Philipp ","Account Manager ","North America SMB ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2450,"Walker","Peter","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2451,"Watson","Marshall","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2453,"Weil","Allison","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2454,"Weinstein","Casey","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2455,"West","Kelley","Client Director","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2456,"Weyers","Lee","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2457,"Wheeler","Will","Account Manager ","Event Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2458,"Whelan","Lorraine","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2460,"White","Teresa","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2461,"Whitney","Neil","Client Executive Comp Spec","Competitive Specialist ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2462,"Wick","Kris","Associate Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2463,"Williams","Tracey","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2464,"Wills","Andy","Area Manager","Supply Chain ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2465,"Wills","Tony","Sr Account Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2466,"Wolk","Ronald","Client Executive","Americas Strategic Accounts Organization","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2467,"Wolters","Erich","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2468,"Wong","Eddy","Sr Account Executive","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2469,"Wong","Jean","Client Partner","Client Partner Group","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2470,"Wood","Ben","Area Manager","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2471,"Woodford","Matt","Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2472,"Wren","Brian","Account Executive","Americas Major Accounts","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2473,"Yacoub","Bashar","Account Executive SMB","Europe Sales ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2474,"Yamashita","Kenichi","Area Manager","Japan Sales","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2475,"Yamawaki","Ayako","Event Attendance Specialist","Event Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2477,"Yu","Angela","Sr Account Executive","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2478,"Zabjek","Mary","Sr Account Executive","Americas Major Accounts","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2479,"Zapoticzny","Jeanne M.","Sales Specialist ","NA","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2481,"Zayed","Wasim","Sr Account Executive","Europe Sales ","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2482,"Zervos","Nate","Account Manager ","North America SMB ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2483,"Zhang","Ada","Area Manager","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2484,"Zhang","Shinny","Account Executive","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2485,"Zhao","Jie","Sr Account Executive SMB","Asia","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2486,"Zieno","Stephanie L.","Account Executive SMB","ANZ","WINNERS","NO","NO","","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2488,"Arlington","Gregory L.","MVP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2489,"Holmes","Daniel J.","MVP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2490,"Obert","Andrew","Regional VP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2491,"Persico","Peter J.","MVP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2492,"Phillips","Timothy H.","MVP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2493,"Reagan","Katharine N.","Regional VP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2494,"Rivard","Alain","MVP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2495,"Schneider","Tod","Regional VP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2497,"Waldheim","Mark","Regional VP ","","HOST","NO","NO","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2498,"Krug","Marcio","MVP Sales","","HOST","YES","YES","Americas Major Accounts","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2499,"Beck","Joseph","GVP","","HOST","NO","NO","Americas Strategic Accounts Organization","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2500,"Capovilla","Frank","Regional VP ","","HOST","NO","NO","Americas Strategic Accounts Organization","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2501,"Julian","Diane L.","GVP ","","HOST","NO","NO","Americas Strategic Accounts Organization","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2502,"Narang","Shilpi","Regional VP ","","HOST","NO","NO","Americas Strategic Accounts Organization","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2503,"Ali","Moe","Regional VP ","","HOST","NO","YES","ANZ","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2504,"Kinslow","Thomas","Regional VP ","","HOST","NO","NO","ASIA","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2505,"Seow","Derek","GVP","","HOST","NO","NO","ASIA","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2506,"Chalk","Mike","GVP","","HOST","NO","NO","Client Partner Group","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2507,"Jackson","Rick","GVP","","HOST","NO","NO","Client Partner Group","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2508,"Potgieter","Kristy","Client Partner Manager","","HOST","NO","NO","Client Partner Group","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2509,"Fahnlander","Beth","Client Partner Manager","","HOST","NO","NO","Client Partner Group","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2510,"Brewer","Karen","VP","","HOST","NO","NO","Competitive Specialist","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2512,"Miller","Tom","MVP ","","HOST","NO","NO","Europe Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2513,"Olchesqui","Michel","Regional VP ","","HOST","NO","NO","Europe Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2514,"Oliveri Del Castillo","Emanuele","Regional VP ","","HOST","NO","NO","Europe Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2515,"Pyatt","Saul","GVP","","HOST","NO","NO","Europe Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2516,"Roel ","Maite","MVP ","","HOST","NO","NO","Europe Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2517,"Swartjes","Marc","Regional VP ","","HOST","NO","NO","Europe Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2518,"Van Ham","Dick","MVP ","","HOST","NO","NO","Europe Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2519,"Wictorsen","Rune","Regional VP ","","HOST","NO","NO","Europe Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2520,"Robertson","Judy","VP","","HOST","NO","NO","Event Attendance","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2521,"Finch","Rob","GVP","","HOST","NO","NO","Event Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2522,"Sato","Haruhisa","VP ","","HOST","YES","NO","Japan Sales","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2523,"McCausland","Valerie","MVP ","","HOST","NO","NO","North America SMB","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2524,"Swan","Nate","GVP ","","HOST","NO","NO","North America SMB","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2525,"Wolter","Jennifer","GVP","","HOST","NO","NO","Sales Communications","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2526,"Cummiskey","James","GVP","","HOST","NO","NO","Sales Operations","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2527,"Muench","Andy","VP Sales Training","","HOST","NO","NO","Sales Operations","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2528,"Gendron","Nancy","AMR Executive Vice President","","HOST","NO","NO","Supply Chain","","10","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2529,"Hall","Gene","Chief Executive Officer","","OC","NO","NO","","","500","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2530,"Davis","Ken ","SVP, End User Programs","","OC","NO","NO","","","490","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2531,"Dawkins","Alwyn","SVP, Worldwide Events","","OC","NO","NO","","","480","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2533,"Hidaka","Nobuhiko","GVP, Japan ","","OC","NO","NO","","","440","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2534,"Hrelic","Darko","SVP, Chief Information Officer","","OC","NO","NO","","","430","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2535,"Kranich","Robin","SVP, Human Resources","","OC","NO","NO","","","470","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2536,"Kutnick","Dale","SVP, Executive Programs","","OC","NO","NO","","","460","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2537,"Lafond","Chris","EVP & Chief Financial Officer ","","OC","NO","NO","","","420","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2539,"Sole","Peter","SVP, Research Board","","OC","NO","NO","","","400","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2540,"Sondergaard","Peter","SVP, Research","","OC","NO","NO","","","390","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2541,"Waern","Per Anders","SVP, Consulting ","","OC","NO","NO","","","380","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (2542,"Yoo","Michael ","SVP, High Tech/Telecomm Programs","","OC","NO","NO","","","370","2013-04-01 00:00:00","NO");');

transaction.executeSql('INSERT INTO yearbookCMS (yearbookID, lastName,firstName,jobTitle,region,type,TA,eagle,teamName,imagePresent,ranking,lastModified,imgLink) VALUES (3000,"Osborne","Susanne","Account Executive","Europe Sales","WINNERS","NO","NO","","NO","10","2013-04-01 00:00:00","NO");'); 

								}
							);


						}
						
